# Basic-Banking-System

## Deployed Website Link -> http://rohitsparksbank.great-site.net/
  
1. Fork the respo (Give ⭐ incase you like the work)
2. Clone the repo in your local machine.
3. Create the database "dbrohit" or any other named (change the settings in spin.php incase you create other named database)
4. Import the tables by using "dbrohit.sql"
